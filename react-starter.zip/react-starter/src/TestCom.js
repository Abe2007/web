import Reacct from 'react'


function TestCom(){
    return (
        <div>
            <h2>Hello</h2>
            <h3>from test componrt</h3>
        </div>
         
    );
}

export default TestCom;